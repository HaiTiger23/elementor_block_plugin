<?php
/**
 * Block Rendering Engine
 *
 * Core rendering function that processes block templates with data.
 *
 * @package CustomBlockBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Render a block by its post ID with provided data.
 *
 * @param int   $block_id The block post ID.
 * @param array $data     Key-value pairs of field data to inject into the template.
 * @return string Rendered HTML output.
 */
function cbb_render_block( $block_id, $data = array() ) {
    $block = get_post( $block_id );

    if ( ! $block || 'custom_block' !== $block->post_type ) {
        return '<!-- CBB: Block not found -->';
    }

    $schema_raw = get_post_meta( $block_id, '_cbb_schema', true );
    $view       = get_post_meta( $block_id, '_cbb_view', true );
    $css        = get_post_meta( $block_id, '_cbb_css', true );
    $js         = get_post_meta( $block_id, '_cbb_js', true );

    $schema = json_decode( $schema_raw, true );

    if ( empty( $view ) ) {
        return '<!-- CBB: Block has no view template -->';
    }

    // Merge defaults from schema with provided data.
    $merged_data = cbb_merge_defaults( $schema, $data );

    return cbb_render_template( $view, $css, $js, $merged_data, $block_id );
}

/**
 * Render a block preview (from raw data, not from DB).
 * Used for live preview in admin editor.
 *
 * @param string $view      The view template (PHP/HTML).
 * @param string $css       The block CSS.
 * @param string $js        The block JS.
 * @param string $schema    The schema JSON string.
 * @param array  $test_data Test data key-value pairs.
 * @return string Rendered HTML output.
 */
function cbb_render_block_preview( $view, $css, $js, $schema, $test_data = array() ) {
    $schema_decoded = json_decode( $schema, true );

    if ( empty( $view ) ) {
        return '<p style="color:#999;text-align:center;padding:40px;">No view template defined.</p>';
    }

    // Merge defaults with test data.
    $merged_data = cbb_merge_defaults( $schema_decoded, $test_data );

    return cbb_render_template( $view, $css, $js, $merged_data, 'preview' );
}

/**
 * Core template rendering function.
 *
 * @param string     $view     The view template string.
 * @param string     $css      The CSS string.
 * @param string     $js       The JS string.
 * @param array      $data     Merged data (defaults + overrides).
 * @param int|string $block_id Block ID or 'preview'.
 * @return string Rendered HTML.
 */
function cbb_render_template( $view, $css, $js, $data, $block_id ) {
    $block_class = 'cbb-block-' . sanitize_html_class( $block_id );

    // Make helper functions available in templates.
    // These are simple wrappers the user can call in their view templates.
    $esc_html = 'esc_html';
    $esc_attr = 'esc_attr';
    $esc_url  = 'esc_url';

    // Extract data into variables for use in the template.
    // Each field name becomes a PHP variable.
    extract( $data, EXTR_SKIP );

    // Render the view template.
    ob_start();
    try {
        eval( '?>' . $view );
    } catch ( \Throwable $e ) {
        ob_end_clean();
        return '<div class="cbb-block ' . esc_attr( $block_class ) . '">'
             . '<p style="color:red;">Template Error: ' . esc_html( $e->getMessage() ) . '</p>'
             . '</div>';
    }
    $html = ob_get_clean();

    // Build the complete output.
    $output = '<div class="cbb-block ' . esc_attr( $block_class ) . '">';
    $output .= $html;
    $output .= '</div>';

    // Append scoped CSS.
    if ( ! empty( $css ) ) {
        $scoped_css = cbb_scope_css( $css, '.' . $block_class );
        $output .= '<style>' . $scoped_css . '</style>';
    }

    // Append isolated JS.
    if ( ! empty( $js ) ) {
        $output .= '<script>(function(){ var blockEl = document.querySelector(".' . esc_js( $block_class ) . '");' . "\n" . $js . "\n" . '})();</script>';
    }

    return $output;
}

/**
 * Merge schema default values with provided data.
 *
 * @param array|null $schema The decoded schema array.
 * @param array      $data   User-provided data.
 * @return array Merged data array.
 */
function cbb_merge_defaults( $schema, $data ) {
    $merged = array();

    if ( ! empty( $schema['fields'] ) && is_array( $schema['fields'] ) ) {
        foreach ( $schema['fields'] as $field ) {
            $name = $field['name'] ?? '';
            if ( empty( $name ) ) {
                continue;
            }

            // Get default value based on field type.
            $default = $field['default'] ?? cbb_get_type_default( $field['type'] ?? 'text' );

            // Use provided data or fall back to default.
            if ( isset( $data[ $name ] ) ) {
                $merged[ $name ] = cbb_sanitize_field_value( $data[ $name ], $field['type'] ?? 'text' );
            } else {
                $merged[ $name ] = $default;
            }
        }
    }

    return $merged;
}

/**
 * Get the default value for a field type.
 *
 * @param string $type Field type.
 * @return mixed Default value.
 */
function cbb_get_type_default( $type ) {
    switch ( $type ) {
        case 'text':
        case 'textarea':
        case 'select':
            return '';
        case 'number':
            return 0;
        case 'image':
            return '';
        case 'boolean':
            return false;
        default:
            return '';
    }
}

/**
 * Sanitize a field value based on its type.
 *
 * @param mixed  $value The value to sanitize.
 * @param string $type  The field type.
 * @return mixed Sanitized value.
 */
function cbb_sanitize_field_value( $value, $type ) {
    switch ( $type ) {
        case 'text':
            return sanitize_text_field( $value );
        case 'textarea':
            return sanitize_textarea_field( $value );
        case 'number':
            return floatval( $value );
        case 'image':
            return esc_url_raw( $value );
        case 'select':
            return sanitize_text_field( $value );
        case 'boolean':
            return (bool) $value;
        default:
            return sanitize_text_field( $value );
    }
}

/**
 * Scope CSS by prefixing all selectors with a parent selector.
 *
 * Simple implementation: handles basic selectors.
 *
 * @param string $css      Raw CSS string.
 * @param string $prefix   Selector prefix (e.g., '.cbb-block-123').
 * @return string Scoped CSS.
 */
function cbb_scope_css( $css, $prefix ) {
    // Remove comments.
    $css = preg_replace( '/\/\*.*?\*\//s', '', $css );

    // Match each CSS rule block.
    $scoped = preg_replace_callback(
        '/([^{]+)\{([^}]*)\}/s',
        function( $matches ) use ( $prefix ) {
            $selectors = $matches[1];
            $rules     = $matches[2];

            // Split multiple selectors by comma.
            $selector_list = array_map( 'trim', explode( ',', $selectors ) );

            $prefixed_selectors = array();
            foreach ( $selector_list as $selector ) {
                if ( empty( $selector ) ) {
                    continue;
                }

                // Handle @media and @keyframes — don't prefix.
                if ( strpos( $selector, '@' ) === 0 ) {
                    $prefixed_selectors[] = $selector;
                } else {
                    $prefixed_selectors[] = $prefix . ' ' . $selector;
                }
            }

            return implode( ",\n", $prefixed_selectors ) . ' {' . $rules . '}';
        },
        $css
    );

    return $scoped;
}
