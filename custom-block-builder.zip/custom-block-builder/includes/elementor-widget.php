<?php
/**
 * Elementor Widget: Custom Block
 *
 * Integrates custom blocks as a native Elementor widget with dynamic controls.
 *
 * @package CustomBlockBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class CBB_Elementor_Widget
 *
 * Custom Elementor widget that renders blocks created with the Custom Block Builder.
 */
class CBB_Elementor_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'cbb_custom_block';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Custom Block', 'custom-block-builder' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-code';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return array( 'general' );
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return array( 'custom', 'block', 'component', 'builder', 'schema' );
    }

    /**
     * Get all available custom blocks.
     *
     * @return array Associative array of block_id => block_name.
     */
    private function get_block_options() {
        $blocks = get_posts( array(
            'post_type'      => 'custom_block',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'orderby'        => 'title',
            'order'          => 'ASC',
        ) );

        $options = array( '' => __( '— Select Block —', 'custom-block-builder' ) );

        foreach ( $blocks as $block ) {
            $options[ $block->ID ] = $block->post_title;
        }

        return $options;
    }

    /**
     * Get schema for a specific block.
     *
     * @param int $block_id Block post ID.
     * @return array|null Decoded schema array or null.
     */
    private function get_block_schema( $block_id ) {
        if ( ! $block_id ) {
            return null;
        }

        $schema_raw = get_post_meta( $block_id, '_cbb_schema', true );
        return json_decode( $schema_raw, true );
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Section: Block Selection.
        $this->start_controls_section(
            'section_block_select',
            array(
                'label' => __( 'Block Selection', 'custom-block-builder' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'block_id',
            array(
                'label'   => __( 'Choose Block', 'custom-block-builder' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => $this->get_block_options(),
                'default' => '',
            )
        );

        $this->add_control(
            'block_info',
            array(
                'type'            => \Elementor\Controls_Manager::RAW_HTML,
                'raw'             => '<p style="color:#93003c;font-style:italic;">' . __( 'Select a block above, then save and refresh to see its controls below.', 'custom-block-builder' ) . '</p>',
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            )
        );

        $this->end_controls_section();

        // Section: Block Fields — dynamically generated for each block.
        $this->register_dynamic_field_controls();
    }

    /**
     * Register dynamic field controls based on all available blocks.
     *
     * Since Elementor registers controls once at widget registration time,
     * we register controls for ALL blocks and use the 'condition' parameter
     * to show only the ones relevant to the selected block.
     */
    private function register_dynamic_field_controls() {
        $blocks = get_posts( array(
            'post_type'      => 'custom_block',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
        ) );

        foreach ( $blocks as $block ) {
            $schema = $this->get_block_schema( $block->ID );

            if ( empty( $schema['fields'] ) ) {
                continue;
            }

            $this->start_controls_section(
                'section_block_fields_' . $block->ID,
                array(
                    'label'     => sprintf( __( '%s — Fields', 'custom-block-builder' ), $block->post_title ),
                    'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
                    'condition' => array(
                        'block_id' => (string) $block->ID,
                    ),
                )
            );

            foreach ( $schema['fields'] as $field ) {
                $this->register_single_field_control( $field, $block->ID );
            }

            $this->end_controls_section();
        }
    }

    /**
     * Register a single Elementor control based on a schema field definition.
     *
     * @param array $field    Schema field definition.
     * @param int   $block_id Block post ID (used for unique control names).
     */
    private function register_single_field_control( $field, $block_id ) {
        $field_name = 'cbb_field_' . $block_id . '_' . sanitize_key( $field['name'] );
        $label      = $field['label'] ?? ucfirst( $field['name'] );
        $default    = $field['default'] ?? '';
        $type       = $field['type'] ?? 'text';

        switch ( $type ) {
            case 'text':
                $this->add_control( $field_name, array(
                    'label'   => $label,
                    'type'    => \Elementor\Controls_Manager::TEXT,
                    'default' => $default,
                ) );
                break;

            case 'textarea':
                $this->add_control( $field_name, array(
                    'label'   => $label,
                    'type'    => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => $default,
                ) );
                break;

            case 'number':
                $this->add_control( $field_name, array(
                    'label'   => $label,
                    'type'    => \Elementor\Controls_Manager::NUMBER,
                    'default' => $default,
                ) );
                break;

            case 'image':
                $this->add_control( $field_name, array(
                    'label'   => $label,
                    'type'    => \Elementor\Controls_Manager::MEDIA,
                    'default' => array(
                        'url' => $default,
                    ),
                ) );
                break;

            case 'select':
                $options = array();
                if ( ! empty( $field['options'] ) && is_array( $field['options'] ) ) {
                    foreach ( $field['options'] as $opt ) {
                        $options[ $opt ] = ucfirst( $opt );
                    }
                }
                $this->add_control( $field_name, array(
                    'label'   => $label,
                    'type'    => \Elementor\Controls_Manager::SELECT,
                    'options' => $options,
                    'default' => $default,
                ) );
                break;

            case 'boolean':
                $this->add_control( $field_name, array(
                    'label'        => $label,
                    'type'         => \Elementor\Controls_Manager::SWITCHER,
                    'label_on'     => __( 'Yes', 'custom-block-builder' ),
                    'label_off'    => __( 'No', 'custom-block-builder' ),
                    'return_value' => '1',
                    'default'      => $default ? '1' : '',
                ) );
                break;
        }
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $block_id = ! empty( $settings['block_id'] ) ? absint( $settings['block_id'] ) : 0;

        if ( ! $block_id ) {
            if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                echo '<div style="padding:40px;text-align:center;color:#999;background:#f9f9f9;border:2px dashed #ddd;border-radius:8px;">';
                echo '<p style="font-size:16px;margin:0;">🧩 ' . esc_html__( 'Select a Custom Block', 'custom-block-builder' ) . '</p>';
                echo '</div>';
            }
            return;
        }

        // Extract field values from settings.
        $data   = array();
        $schema = $this->get_block_schema( $block_id );

        if ( ! empty( $schema['fields'] ) ) {
            foreach ( $schema['fields'] as $field ) {
                $control_name = 'cbb_field_' . $block_id . '_' . sanitize_key( $field['name'] );

                if ( isset( $settings[ $control_name ] ) ) {
                    $value = $settings[ $control_name ];

                    // Handle image field — Elementor returns array with 'url'.
                    if ( $field['type'] === 'image' && is_array( $value ) ) {
                        $value = $value['url'] ?? '';
                    }

                    // Handle boolean field.
                    if ( $field['type'] === 'boolean' ) {
                        $value = ( $value === '1' || $value === 'yes' );
                    }

                    $data[ $field['name'] ] = $value;
                }
            }
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Output is escaped in renderer.
        echo cbb_render_block( $block_id, $data );
    }

    /**
     * Render widget output in the Elementor editor (JS template).
     *
     * Since we use server-side rendering with PHP eval, we show a placeholder
     * and use AJAX to fetch the actual preview.
     */
    protected function content_template() {
        ?>
        <#
        if ( ! settings.block_id ) {
        #>
            <div style="padding:40px;text-align:center;color:#999;background:#f9f9f9;border:2px dashed #ddd;border-radius:8px;">
                <p style="font-size:16px;margin:0;">🧩 <?php echo esc_html__( 'Select a Custom Block', 'custom-block-builder' ); ?></p>
            </div>
        <#
        } else {
        #>
            <div class="cbb-elementor-preview-loading" style="padding:20px;text-align:center;color:#666;">
                <p>⏳ <?php echo esc_html__( 'Loading block preview...', 'custom-block-builder' ); ?></p>
            </div>
        <#
        }
        #>
        <?php
    }
}
