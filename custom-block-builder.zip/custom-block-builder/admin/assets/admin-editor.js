/**
 * Custom Block Builder — Admin Editor JavaScript
 *
 * Initializes CodeMirror editors, generates test data forms from schema,
 * and handles AJAX-powered live preview in an iframe.
 */

(function ($) {
    'use strict';

    // ==========================================
    // State
    // ==========================================

    let cmSchema = null;
    let cmView = null;
    let cmCss = null;
    let cmJs = null;
    let previewTimer = null;
    let isAutoPreview = true;

    // ==========================================
    // Initialize CodeMirror Editors
    // ==========================================

    function initCodeEditors() {
        // Schema Editor (JSON)
        const schemaEl = document.getElementById('cbb-schema-editor');
        if (schemaEl) {
            cmSchema = wp.codeEditor.initialize(schemaEl, {
                codemirror: {
                    mode: 'application/json',
                    lineNumbers: true,
                    lineWrapping: true,
                    matchBrackets: true,
                    autoCloseBrackets: true,
                    foldGutter: true,
                    gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
                    theme: 'default',
                    indentUnit: 2,
                    tabSize: 2,
                    indentWithTabs: false,
                },
            }).codemirror;

            cmSchema.on('change', function () {
                updateAvailableVars();
                updateTestDataForm();
                schedulePreview();
            });
        }

        // View Template Editor (PHP/HTML)
        const viewEl = document.getElementById('cbb-view-editor');
        if (viewEl) {
            cmView = wp.codeEditor.initialize(viewEl, {
                codemirror: {
                    mode: 'application/x-httpd-php',
                    lineNumbers: true,
                    lineWrapping: true,
                    matchBrackets: true,
                    matchTags: true,
                    autoCloseTags: true,
                    autoCloseBrackets: true,
                    theme: 'default',
                    indentUnit: 2,
                    tabSize: 2,
                },
            }).codemirror;

            cmView.on('change', function () {
                schedulePreview();
            });
        }

        // CSS Editor
        const cssEl = document.getElementById('cbb-css-editor');
        if (cssEl) {
            cmCss = wp.codeEditor.initialize(cssEl, {
                codemirror: {
                    mode: 'text/css',
                    lineNumbers: true,
                    lineWrapping: true,
                    matchBrackets: true,
                    autoCloseBrackets: true,
                    theme: 'default',
                    indentUnit: 2,
                    tabSize: 2,
                },
            }).codemirror;

            cmCss.on('change', function () {
                schedulePreview();
            });
        }

        // JS Editor
        const jsEl = document.getElementById('cbb-js-editor');
        if (jsEl) {
            cmJs = wp.codeEditor.initialize(jsEl, {
                codemirror: {
                    mode: 'text/javascript',
                    lineNumbers: true,
                    lineWrapping: true,
                    matchBrackets: true,
                    autoCloseBrackets: true,
                    theme: 'default',
                    indentUnit: 2,
                    tabSize: 2,
                },
            }).codemirror;

            cmJs.on('change', function () {
                schedulePreview();
            });
        }
    }

    // ==========================================
    // Parse Schema JSON
    // ==========================================

    function getSchema() {
        if (!cmSchema) return { fields: [] };

        try {
            const raw = cmSchema.getValue();
            const parsed = JSON.parse(raw);
            return parsed && parsed.fields ? parsed : { fields: [] };
        } catch (e) {
            return { fields: [] };
        }
    }

    // ==========================================
    // Update Available Variables Display
    // ==========================================

    function updateAvailableVars() {
        const container = document.getElementById('cbb-available-vars');
        if (!container) return;

        const schema = getSchema();

        if (!schema.fields || schema.fields.length === 0) {
            container.innerHTML = '';
            return;
        }

        let html = '<span style="font-size:12px;color:#64748b;margin-right:8px;">Available vars:</span>';
        schema.fields.forEach(function (field) {
            if (field.name) {
                html += '<span class="cbb-var-badge">$' + escapeHtml(field.name) + '</span>';
            }
        });

        container.innerHTML = html;
    }

    // ==========================================
    // Generate Test Data Form
    // ==========================================

    function updateTestDataForm() {
        const container = document.getElementById('cbb-test-data-form');
        if (!container) return;

        const schema = getSchema();

        if (!schema.fields || schema.fields.length === 0) {
            container.innerHTML = '<p class="cbb-placeholder-text">Define a schema above to see test fields here.</p>';
            return;
        }

        let html = '';

        schema.fields.forEach(function (field) {
            if (!field.name) return;

            const name = escapeHtml(field.name);
            const label = escapeHtml(field.label || field.name);
            const type = field.type || 'text';
            const defaultVal = field.default !== undefined ? escapeHtml(String(field.default)) : '';
            const fieldId = 'cbb-test-' + name;

            html += '<div class="cbb-field-group">';
            html += '<label class="cbb-field-label" for="' + fieldId + '">' + label;
            html += '<span class="cbb-field-type-badge">' + escapeHtml(type) + '</span>';
            html += '</label>';

            switch (type) {
                case 'text':
                    html += '<input type="text" id="' + fieldId + '" data-field="' + name + '" value="' + defaultVal + '" />';
                    break;

                case 'textarea':
                    html += '<textarea id="' + fieldId + '" data-field="' + name + '">' + defaultVal + '</textarea>';
                    break;

                case 'number':
                    html += '<input type="number" id="' + fieldId + '" data-field="' + name + '" value="' + defaultVal + '" />';
                    break;

                case 'image':
                    html += '<input type="url" id="' + fieldId + '" data-field="' + name + '" value="' + defaultVal + '" placeholder="https://..." />';
                    break;

                case 'select':
                    html += '<select id="' + fieldId + '" data-field="' + name + '">';
                    if (field.options && Array.isArray(field.options)) {
                        field.options.forEach(function (opt) {
                            const selected = String(opt) === String(field.default) ? ' selected' : '';
                            html += '<option value="' + escapeHtml(opt) + '"' + selected + '>' + escapeHtml(opt) + '</option>';
                        });
                    }
                    html += '</select>';
                    break;

                case 'boolean':
                    const checked = field.default ? ' checked' : '';
                    html += '<div class="cbb-toggle-wrapper">';
                    html += '<input type="checkbox" id="' + fieldId + '" data-field="' + name + '" class="cbb-toggle-switch"' + checked + ' />';
                    html += '<span>' + (field.default ? 'Yes' : 'No') + '</span>';
                    html += '</div>';
                    break;

                default:
                    html += '<input type="text" id="' + fieldId + '" data-field="' + name + '" value="' + defaultVal + '" />';
            }

            html += '</div>';
        });

        container.innerHTML = html;

        // Bind change events for auto-preview.
        $(container).find('input, textarea, select').on('input change', function () {
            // Update toggle label.
            if ($(this).hasClass('cbb-toggle-switch')) {
                $(this).siblings('span').text(this.checked ? 'Yes' : 'No');
            }
            schedulePreview();
        });
    }

    // ==========================================
    // Collect Test Data
    // ==========================================

    function collectTestData() {
        const data = {};
        const schema = getSchema();

        if (!schema.fields) return data;

        schema.fields.forEach(function (field) {
            if (!field.name) return;

            const el = document.querySelector('[data-field="' + field.name + '"]');
            if (!el) return;

            const type = field.type || 'text';

            switch (type) {
                case 'boolean':
                    data[field.name] = el.checked;
                    break;
                case 'number':
                    data[field.name] = parseFloat(el.value) || 0;
                    break;
                default:
                    data[field.name] = el.value;
            }
        });

        return data;
    }

    // ==========================================
    // Live Preview
    // ==========================================

    function schedulePreview() {
        if (!isAutoPreview) return;

        clearTimeout(previewTimer);
        previewTimer = setTimeout(function () {
            triggerPreview();
        }, 600);
    }

    function triggerPreview() {
        const statusEl = document.getElementById('cbb-preview-status');

        if (statusEl) {
            statusEl.textContent = '⏳ Rendering...';
            statusEl.className = 'cbb-preview-status loading';
        }

        const requestData = {
            action: 'cbb_preview_block',
            nonce: cbbAdmin.nonce,
            view: cmView ? cmView.getValue() : '',
            css: cmCss ? cmCss.getValue() : '',
            js: cmJs ? cmJs.getValue() : '',
            schema: cmSchema ? cmSchema.getValue() : '{"fields":[]}',
            test_data: JSON.stringify(collectTestData()),
        };

        $.post(cbbAdmin.ajaxUrl, requestData, function (response) {
            if (response.success) {
                renderPreviewIframe(response.data.html);

                if (statusEl) {
                    statusEl.textContent = '✅ Updated';
                    statusEl.className = 'cbb-preview-status success';
                }
            } else {
                if (statusEl) {
                    statusEl.textContent = '❌ Error: ' + (response.data?.message || 'Unknown');
                    statusEl.className = 'cbb-preview-status error';
                }
            }
        }).fail(function () {
            if (statusEl) {
                statusEl.textContent = '❌ Network error';
                statusEl.className = 'cbb-preview-status error';
            }
        });
    }

    function renderPreviewIframe(html) {
        const iframe = document.getElementById('cbb-preview-iframe');
        if (!iframe) return;

        const doc = iframe.contentDocument || iframe.contentWindow.document;

        const fullHtml = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            padding: 16px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 14px;
            line-height: 1.6;
            color: #1e293b;
            background: #fff;
        }
        img { max-width: 100%; height: auto; }
    </style>
</head>
<body>
    ${html}
</body>
</html>`;

        doc.open();
        doc.write(fullHtml);
        doc.close();
    }

    // ==========================================
    // Utilities
    // ==========================================

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    // ==========================================
    // Initialization
    // ==========================================

    $(document).ready(function () {
        initCodeEditors();
        updateAvailableVars();
        updateTestDataForm();

        // Manual preview button.
        $('#cbb-preview-btn').on('click', function (e) {
            e.preventDefault();
            triggerPreview();
        });

        // Auto-preview toggle.
        $('#cbb-auto-preview').on('change', function () {
            isAutoPreview = this.checked;
        });

        // Initial preview after a short delay (let CodeMirror initialize).
        setTimeout(function () {
            triggerPreview();
        }, 1000);
    });
})(jQuery);
